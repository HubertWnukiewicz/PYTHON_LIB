

print("INIT NANAN")

