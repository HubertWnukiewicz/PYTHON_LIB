from enum import Enum

def printFileName():
    print("Event")

class Event(Enum):
    Uroczysta_kolacja=1,
    Rodzinne_Przyjecie=2,
    Sniadanie=3,
    Obiad=4,
    Kolacja=5
