def printText():
    print("Testowa paczka skryptu test2")
